from django.apps import AppConfig


class WelcomeConfig(AppConfig):
    name = 'welcome'
